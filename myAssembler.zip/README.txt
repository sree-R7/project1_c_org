go to appropriate directory where .cpp and .s files are located. 

open terminal in vscode or equivalent

To compile the code type: g++ .\myAssembler.cpp -o myAssembler

To run executable type: .\myAssembler test_case1.s

This will generate an Obj file called myAssembler. 

**gcc version used: 8.3.0**

